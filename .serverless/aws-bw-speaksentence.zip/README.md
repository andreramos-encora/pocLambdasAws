# awsLambda
Simple application using lambda and Serverless framework to expose an endpoint and execute lambda functions

Requirements;

Install npm and serverless package:
npm install serverless

How to run the app:

1. Type serverless deploy on command line to deploy the app on AWS. It will prompt for AWS secrets in case if you havent configured
2. Wait the deploy to be completed
3. Copy the URL of the deployed app in AWS
4. Test on postman

